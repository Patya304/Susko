<!-- a hello world karakterkonstans
kiirása standard outputra -->
<?="hello world!"?>