<?php

$num1 = rand(min: 1, max: 50);
$num2 = rand(min: 1, max: 50);


$operators = ['+', '-', '*'];
$operator = $operators[array_rand(array: $operators)];


$kerdes = "{$num1} {$operator} {$num2}";


session_start();
$_SESSION['captcha_answer'] = eval("return {$num1} {$operator} {$num2};");
?>