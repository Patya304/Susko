<?php
	session_start() ;
?>
<!DOCTYPE html>
<html>
  <head>

  </head>

  <style>

    body
    {
	margin : 0 ;
    }

    div#menu
    {
	padding          : 0 8px        ;
	background-color : #AAA         ;
	text-align       : center       ;
    }

    div#menu a
    {
	display          : inline-block ;
	padding          : 8px 0        ;
	width            : 100px        ;
	color            : #666         ;
	text-decoration  : none         ;
	text-align       : center       ;
    }

    div#menu a:hover
    {
	background-color : #CCC         ;
	color            : #000         ;
    }

    div#tartalom
    {
	margin           : 32px auto    ;
	width            : 920px        ;
	min-height       : 420px        ;
    }

    div#lablec
    {
	padding          : 8px     ;
	background-color : #666         ;
	color            : #FFF         ;
    }

  </style>

  <body>

    <div id='menu'>
      [
	<a href='./'               > Kezdőlap    </a>  |
	<a href='./?p=gyik'        > GY.I.K      </a>  |
	<a href='./?p=rolunk'      > Rólunk      </a>  | 
	<a href='./?p=szavazas'    > Szavazás    </a>  |
	<a href='./?p=vendegkonyv' > Vendégkönyv </a>   
      ]
    </div>

    <div id='tartalom'>

<?php

    if( isset($_GET['p']) )  $p = $_GET['p'] ;
    else                     $p = ""         ;

    if( $p==""            )  print "<h2> Akciók </h2>"                    ; else
    if( $p=="gyik"        )  include("gyik.php")                          ; else
    if( $p=="rolunk"      )  include("rolunk.php")                        ; else
    if( $p=="szavazas"    )  include("szavazas.php")                      ; else
    if( $p=="vendegkonyv" )  include("vendegkonyv_form.php")              ; else
	                     include("404.php")                           ;
?>

    </div>

    <iframe name='kisablak' width=480 height=120 frameborder=0></iframe>

    <div id='lablec'>

	&copy; enoldalam.hu - 2024.

<?php

	$fajlnev = "szamlalo.txt" ;

	if( !file_exists($fajlnev) )
	{
		$fp = fopen( $fajlnev , "w" ) ;
		fwrite( $fp , "0" ) ;
		fclose( $fp ) ;
	}

	$fp = fopen( $fajlnev , "r" ) ;
	$n  = fread( $fp ,  filesize($fajlnev) ) ;
	fclose( $fp ) ;

	if( !isset($_SESSION['ittjartam'])  )
	{
		$n++ ;
		$_SESSION['ittjartam'] = 1 ;

		$fp = fopen( $fajlnev , "w" ) ;
		fwrite( $fp , $n ) ;
		fclose( $fp ) ;
	}

	print "	- Te vagy a $n. látogató." ;

?>





	<div style='float:right;'>
<?php
	$honapok  = array( "", "január", "február", "március", "április", "május", "június", "július", "augusztus", "szeptember", "október", "november", "december" ) ;
	$napnevek = array( "", "hétfő", "kedd", "szerda", "csütörtök", "péntek", "szombat", "vasárnap" ) ;

	include("nevnapok.php") ;
	$mainevnap = "Ma ünnepli névnapját: " . nevnapos( date("Y") , date("n") , date("j")  ) ;

	print date("Y. ") . $honapok[date("n")] . date(" d., ") . $napnevek[date("N")] . " - " . $mainevnap ;
?>
	</div>

    </div>


  </body>
</html>

