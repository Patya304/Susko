<?php

   session_start() ;


//    print_r( $_POST ) ;

    $fajlnev = "szavazas.txt";
    if( !file_exists($fajlnev) )
    {
	$fp = fopen( $fajlnev , "w" ) ;
	fwrite( $fp , "0;0;0;0" ) ;
	fclose( $fp ) ;
    }

    $fp = fopen( $fajlnev , "r" ) ;
    $sz = fread( $fp , filesize($fajlnev) ) ;
    fclose( $fp ) ;

//    print $sz ;

    $allas = explode( ";" , $sz ) ;

//    print_r( $allas ) ;

    $m = $_POST['evszak']-1 ;

    $allas[$m]++ ;

//    print_r( $allas ) ;

    $sz = implode( ";" , $allas ) ;

//    print $sz ;

    $fp = fopen( $fajlnev , "w" ) ;
    fwrite( $fp , $sz ) ;
    fclose( $fp ) ;

    $_SESSION['szavazva'] = 1 ;

?>