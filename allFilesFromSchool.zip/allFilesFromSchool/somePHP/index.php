<?php
	
	phpinfo() ;

?>