import random

# Kártyák értékei
kartya_ertekek = {
    "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
    "10": 10, "J": 10, "Q": 10, "K": 10, "A": 11
}

# Pakli létrehozása
def letrehoz_pakli():
    return ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"] * 4

# Pakli keverése
def kever_pakli(pakli):
    random.shuffle(pakli)

# Kez értékének kiszámítása
def kez_ertek(kez):
    ertek = 0
    aszok_szama = 0
    for kartya in kez:
        ertek += kartya_ertekek[kartya]
        if kartya == "A":
            aszok_szama += 1
    
    # Ha a kártyák összértéke meghaladja a 21-et és van ász, akkor az ászt 11-ről 1-re változtatjuk
    while ertek > 21 and aszok_szama > 0:
        ertek -= 10
        aszok_szama -= 1
    
    return ertek

# Játékos kör (a játékos kér kártyát, ha az érték kisebb, mint 21)
def jatekos_kor(jatekos_kez, pakli):
    while kez_ertek(jatekos_kez) < 21:
        uj_kartya = pakli.pop(0)
        jatekos_kez.append(uj_kartya)

# Gép kör (a gép kér kártyát, ha a keze kisebb, mint 17)
def gep_kor(gep_kez, pakli):
    while kez_ertek(gep_kez) < 17:
        uj_kartya = pakli.pop(0)
        gep_kez.append(uj_kartya)

# Egy játék lejátszása
def jatsz_blackjack(lapok_gyakorisaga):
    pakli = letrehoz_pakli()  # Minden játékhoz új paklit hozunk létre
    kever_pakli(pakli)  # Pakli keverése

    # Osztás: 2 lapot kap mind a játékos, mind a gép
    jatekos_kez = [pakli.pop(0), pakli.pop(0)]
    gep_kez = [pakli.pop(0), pakli.pop(0)]

    # A kártyák gyakoriságának frissítése
    lapok_gyakorisaga[jatekos_kez[0]] += 1
    lapok_gyakorisaga[jatekos_kez[1]] += 1
    lapok_gyakorisaga[gep_kez[0]] += 1
    lapok_gyakorisaga[gep_kez[1]] += 1

    # A játékos és a gép körének szimulálása
    jatekos_kor(jatekos_kez, pakli)
    gep_kor(gep_kez, pakli)

    # A további kártyák gyakoriságának frissítése a körök után
    for kartya in jatekos_kez + gep_kez:
        lapok_gyakorisaga[kartya] += 1

# Adatok mentése txt fájlba
def mentes_txt_be(lapok_gyakorisaga):
    with open("blackjack_lapok_gyakorisaga.txt", "w") as f:
        f.write("Lap\tGyakoriság\n")
        for lap, gyakorisag in lapok_gyakorisaga.items():
            f.write(f"{lap}\t{gyakorisag}\n")
    print("\nA lapok gyakorisága elmentve a blackjack_lapok_gyakorisaga.txt fájlba.")

# A szimuláció futtatása
def futtass_szimulaciot(jatekok_szama):
    lapok_gyakorisaga = {str(i): 0 for i in range(2, 11)}  # Kártyák 2-től 10-ig
    lapok_gyakorisaga.update({"J": 0, "Q": 0, "K": 0, "A": 0})  # Kártyák J, Q, K, A

    for _ in range(jatekok_szama):
        jatsz_blackjack(lapok_gyakorisaga)

    # Mentés .txt fájlba
    mentes_txt_be(lapok_gyakorisaga)

if __name__ == "__main__":
    print("Blackjack szimuláció kezdete")
    futtass_szimulaciot(1000)  # 1000 játék szimulálása
