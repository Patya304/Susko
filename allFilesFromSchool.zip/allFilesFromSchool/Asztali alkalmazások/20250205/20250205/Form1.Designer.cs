﻿namespace _20250205
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_plyer = new System.Windows.Forms.TextBox();
            this.txt_tippMix = new System.Windows.Forms.TextBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.lbl_Db = new System.Windows.Forms.Label();
            this.btn_exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(135, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Játékos neve";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Játékos tippjei";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txt_plyer
            // 
            this.txt_plyer.Location = new System.Drawing.Point(220, 124);
            this.txt_plyer.Name = "txt_plyer";
            this.txt_plyer.Size = new System.Drawing.Size(176, 20);
            this.txt_plyer.TabIndex = 2;
            // 
            // txt_tippMix
            // 
            this.txt_tippMix.Location = new System.Drawing.Point(220, 172);
            this.txt_tippMix.Name = "txt_tippMix";
            this.txt_tippMix.Size = new System.Drawing.Size(218, 20);
            this.txt_tippMix.TabIndex = 3;
            this.txt_tippMix.TextChanged += new System.EventHandler(this.txt_tippMix_TextChanged);
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(220, 252);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(176, 23);
            this.btn_Add.TabIndex = 4;
            this.btn_Add.Text = "Játékos hozzáadása";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // lbl_Db
            // 
            this.lbl_Db.AutoSize = true;
            this.lbl_Db.Location = new System.Drawing.Point(463, 175);
            this.lbl_Db.Name = "lbl_Db";
            this.lbl_Db.Size = new System.Drawing.Size(28, 13);
            this.lbl_Db.TabIndex = 6;
            this.lbl_Db.Text = "0 db";
            this.lbl_Db.Click += new System.EventHandler(this.lbl_Db_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(415, 251);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(75, 23);
            this.btn_exit.TabIndex = 7;
            this.btn_exit.Text = "Kilépés";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 450);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.lbl_Db);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.txt_tippMix);
            this.Controls.Add(this.txt_plyer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Tipp-sz MIX";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_plyer;
        private System.Windows.Forms.TextBox txt_tippMix;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Label lbl_Db;
        private System.Windows.Forms.Button btn_exit;
    }
}

