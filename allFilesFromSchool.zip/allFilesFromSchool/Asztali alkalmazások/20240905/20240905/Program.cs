﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20240905
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Szeve Szeva Szeva"); // comment
            Console.ReadKey(); // () fügyvényhívó operátor, {} blokk határoló, [] elemket elérése indexelésnél

            // a változókat deklarálni és inicializálni kell
            /* 
             * szoveg: str ""
             * karakter: char ''
             * szam - egesz: int/unit 32bi
             *        short: short/ushort 16bit
             *        byte/sbyte: 6bit
             *        long/ulong: 64bit
             *      - valas: double/decimal
             * logikai: bool true/false
             * datum es ido: DateTime, TimeSpan
             */

        }
    }
}
