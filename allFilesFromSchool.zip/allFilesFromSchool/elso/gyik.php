<h2> Gyakran ismételt kérdések </h2>

Amit a leggyakrabban kérdeznek:

<ul>
	<li>Hol a söröm?
	<li>Miért nincs már vége az órának?
</ul>
