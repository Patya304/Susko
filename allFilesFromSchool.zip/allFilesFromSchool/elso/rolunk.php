<h2> Rólunk, kapcsolat </h2>

<p>
	Mi vagyunk a mi vagyunk, és itt vagyunk:
</p>

<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d30540.40634097969!2d19.085431380130665!3d47.423330149051424!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1shu!2shu!4v1728391083837!5m2!1shu!2shu" 
        width="600" height="450" 
        style="margin-left:48px; border:solid 4px #CCC; border-radius:16px;" 
	allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
</iframe>
